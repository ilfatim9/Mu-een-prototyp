MU’EEN brand assets

Logo: logo/mueen-logo.png
Core colors: #176B68 (dark teal), #49AFA3 (medium teal)
Typography: Inter (English), Tajawal (Arabic)
Reference: reference/color-and-typography.png
